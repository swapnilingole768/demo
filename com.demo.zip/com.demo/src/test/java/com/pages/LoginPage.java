package com.pages;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;
import com.demo.base.BaseClass;

import utilities.ReadData;

public class LoginPage extends BaseClass{
	
	public LoginPage()
	{
		PageFactory.initElements(driver, this);
	}
    @FindBy(xpath="//img[@src='img/logo-big.png']") private WebElement img;
    @FindBy(xpath="//h4[@class='auth-header']") private WebElement label;
    @FindBy(xpath="//label[normalize-space()='Username']") private WebElement userName;
    @FindBy(xpath="//label[normalize-space()='Password']") private WebElement pass;
    @FindBy(xpath="//div[@class='pre-icon os-icon os-icon-user-male-circle']") private WebElement userIcon;
    @FindBy(xpath="//div[@class='pre-icon os-icon os-icon-fingerprint']") private WebElement passwordIcon;
    @FindBy(xpath="//button[@id='log-in']") private WebElement loginBtn;
    @FindBy(xpath="//input[@type='checkbox']") private WebElement checkBox;
    @FindBy(xpath="//label[@class='form-check-label']") private WebElement rememberMelabel;
    @FindBy(xpath="//h4[@class='auth-header']") private WebElement headerLine ;
    @FindBy(xpath="//input[@id='password']") private WebElement pass2;
    @FindBy(xpath="//input[@id='username']") private WebElement user1;
    
    public void scrolldown()
    {
    	JavascriptExecutor js= (JavascriptExecutor) driver;
    	js.executeScript("window.scrollBy(0, 1000)");
    }
    public Boolean verifyLogo()
	{
		return img.isDisplayed();
	}
	
	public String verifyTitleOfApp()
	{
		return driver.getTitle();
	}
	
	public String verifyUrlOfApp()
	{
		return driver.getCurrentUrl();
	}
	public Boolean verifyAllLabels()
	{
		 return label.isDisplayed();
		 
	}
	public Boolean verifyuserName()
	{
		return userName.isDisplayed();
	}
	public Boolean verifypass()
	{
		return pass.isDisplayed();
	}
	public Boolean verifyRememberMeLabel()
	{
		return rememberMelabel.isDisplayed();
	}
	public String loginToApplication() throws IOException
	{
	//	logger=report.createTest("Login to Assignment Web Application");
		//UserName.sendKeys(ReadData.readPropertyFile("username"));
		user1.sendKeys("Swapnil123");
	//	logger.log(Status.INFO, "username is entered");
		pass2.sendKeys(ReadData.readPropertyFile("password"));
//		logger.log(Status.INFO, "password is entered");
		loginBtn.click();
	//	logger.log(Status.INFO, "Button is clicked");
	//	logger.log(Status.INFO, "Login Successfully!");


		return driver.getCurrentUrl();
	}
}
