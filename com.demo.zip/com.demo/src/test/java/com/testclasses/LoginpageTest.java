package com.testclasses;

import java.io.IOException;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.demo.base.BaseClass;
import com.pages.LoginPage;

public class LoginpageTest extends BaseClass{

	LoginPage lp;
	
	@BeforeMethod
	public void setUp() throws IOException
	{
		initialization(); 
	    lp=new LoginPage();
	}
	@Test(priority=1)
public void verifyUrlTest() throws IOException
{
		String expectedUrl="https://sakshingp.github.io/assignment/login.html";
        String actualUrl=lp.verifyUrlOfApp();
	    Assert.assertEquals(expectedUrl, actualUrl);
	    Reporter.log("Original Url of Application-" +actualUrl);

		}

	@Test(priority = 2)
	public void verifyLogo()
	{
		Boolean result=lp.verifyLogo();
		Assert.assertEquals(result, true);
		Reporter.log("Visibility of Logo-" +result);
	}
	@Test
	public void loginTest() throws IOException
	{
		lp.loginToApplication();
	}

	@AfterMethod
	public void tearDown(ITestResult it) throws IOException
	{
//		if(ITestResult.FAILURE==it.getStatus())
//		{
//		//	CaptureScreenShot.ScreenShot(it.getName());
//		}
		//report.flush();
		if (driver != null) {
            driver.quit();
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
